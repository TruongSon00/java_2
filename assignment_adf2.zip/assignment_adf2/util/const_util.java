package assignment_adf2.util;

public class const_util {
    public static final String url = "jdbc:sqlserver://127.0.0.1:1433;databaseName=adf2";
    public static final String user = "SA";
    public static final String password = "Son123456";
}
