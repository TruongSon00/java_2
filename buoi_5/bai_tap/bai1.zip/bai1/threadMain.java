package buoi_5.bai_tap.bai1;

import java.io.File;

public class threadMain {
    public static void main(String[] args) {

        File root = new File(System.getProperty("user.dir"));
        File fileRoot = new File(root, "buoi_5/bai_tap/bai1/test_remove_file");
        File newFile = new File(root, "buoi_5/bai_tap/bai1/dirBK");

        newFile.mkdirs();

        threadRunFile luongChayFile = new threadRunFile(fileRoot, newFile);
        threadCheck luongCheck = new threadCheck(newFile);

        luongChayFile.start();
        luongCheck.start();

    }
}
